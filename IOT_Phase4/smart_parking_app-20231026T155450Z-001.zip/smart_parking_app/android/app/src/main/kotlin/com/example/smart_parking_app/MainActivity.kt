package com.example.smart_parking_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
